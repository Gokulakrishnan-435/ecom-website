export let Addtobasket = "Add_Tobasket";
export let RemoveFromCart = "RemoveFromCart";
export let Set_cart_empty = "Set_cart_empty";