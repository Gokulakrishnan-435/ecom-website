import { combineReducers } from "redux";
import reducer from "./AuthReducer";

let Reducer = combineReducers({ reducer });

export default Reducer;
